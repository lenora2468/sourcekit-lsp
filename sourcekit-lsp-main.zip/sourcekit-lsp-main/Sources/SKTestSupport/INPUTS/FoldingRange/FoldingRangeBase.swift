/// DC1
/// - Returns: DC1

/**
  DC2

  - Parameter param: DC2

  - Throws: DC2
  DC2
  DC2

  - Returns: DC2
*/
struct S {
  //c1
  //c2
  /*
   c3
  */
  var abc: Int

  func test(a: Int) {
    guard a > 0 else { return }
    self.abc = a
  }
  /* c4 */
}

//
// MARK: - A mark! -
//

//
// FIXME: a fixme
//

// a https://www.example.com URL

/*fr:base*/
