#include "lib-generated.h"

int main(int argc, const char *argv[]) {
  return /*libX:call:main*/libX(argc);
}
