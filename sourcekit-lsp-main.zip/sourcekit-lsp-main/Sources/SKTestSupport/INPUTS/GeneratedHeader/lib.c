int /*libX:def*/libX(int value) {
  return value ? 22 : 0;
}
