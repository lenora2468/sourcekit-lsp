#include "shared.h"
#include "unique.h"

void /*d_func*/d_func(void) {
  shared();
  unique();
}
