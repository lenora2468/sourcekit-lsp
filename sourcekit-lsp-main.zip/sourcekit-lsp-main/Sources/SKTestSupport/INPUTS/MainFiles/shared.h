void /*shared*/shared(void);
