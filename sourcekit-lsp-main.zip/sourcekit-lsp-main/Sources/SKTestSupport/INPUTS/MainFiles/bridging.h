void /*bridging*/bridging(void);
