func /*a_func*/a_func() {
  b_func()
  bridging()
}
