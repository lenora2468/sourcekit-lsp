func /*b_func*/b_func() {
  a_func()
  bridging()
}
