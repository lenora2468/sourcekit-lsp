#include "shared.h"
#include "bridging.h"

void /*c_func*/c_func(void) {
  shared();
  bridging();
}
