func /*a:def*/a() {
  /*b:call*/b()
  /*c:call*/c()
}
