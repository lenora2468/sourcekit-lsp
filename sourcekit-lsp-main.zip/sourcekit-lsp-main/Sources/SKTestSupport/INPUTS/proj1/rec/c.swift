func /*c*/c() {
}
