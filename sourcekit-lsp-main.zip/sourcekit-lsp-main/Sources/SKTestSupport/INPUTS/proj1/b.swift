func /*b:def*/b() {
  /*a:call*/a()
}
