import A
import B
public func ccc() {
  /*aaa:call:c*/aaa()
  /*bbb:call*/bbb()
}
