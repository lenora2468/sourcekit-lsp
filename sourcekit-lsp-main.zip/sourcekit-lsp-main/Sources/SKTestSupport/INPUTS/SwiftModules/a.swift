public func /*aaa:def*/aaa() {}
