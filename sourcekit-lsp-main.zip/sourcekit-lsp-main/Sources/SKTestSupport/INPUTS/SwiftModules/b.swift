import A
public func /*bbb:def*/bbb() {
  /*aaa:call*/aaa()
}
