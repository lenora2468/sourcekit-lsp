/*loc*/

#if FOO
void foo() {}
#else
void foo() {}
#endif

int main() {
  foo();
}
