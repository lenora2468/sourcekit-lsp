#ifndef ClangModuleA_h
#define ClangModuleA_h

void func_ClangModuleA(void);

#endif /* ClangModuleA_h */
