/*main_file*/
@import ClangModuleA;

void test(void) {
  func_ClangModuleA();
}
