struct /*Object*/Object {
  int field;
};

struct Object * newObject();
