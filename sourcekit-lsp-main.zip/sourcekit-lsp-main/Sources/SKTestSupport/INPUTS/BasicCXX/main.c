#include /*Object:include:main*/"Object.h"

int main(int argc, const char *argv[]) {
  struct /*Object:ref:main*/Object *obj = newObject();
  return obj->field;
}
