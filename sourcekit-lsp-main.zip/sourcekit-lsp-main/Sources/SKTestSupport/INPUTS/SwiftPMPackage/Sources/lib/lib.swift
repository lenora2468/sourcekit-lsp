public struct Lib {
  public func /*Lib.foo:def*/foo() {}

  public init() {}
}
