import lib

Lib() . /*Lib.foo:call*/foo()
