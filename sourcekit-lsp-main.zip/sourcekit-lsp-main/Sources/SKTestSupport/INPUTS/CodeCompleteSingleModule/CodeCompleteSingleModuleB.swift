func test(a: A) {
  a . /*cc:A*/
}
