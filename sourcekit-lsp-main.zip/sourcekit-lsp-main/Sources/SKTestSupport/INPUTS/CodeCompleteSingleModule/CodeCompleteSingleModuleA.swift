struct A {
  func method(a b: Int) {}
}
